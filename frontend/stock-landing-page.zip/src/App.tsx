import React from 'react';
import { ArrowUpRight, Code2, Star, Play } from 'lucide-react';

const Navbar = () => (
  <div className="pt-4 px-4">
    <nav className="flex items-center justify-between px-6 py-4 max-w-7xl mx-auto w-full bg-white/5 border border-white/10 rounded-full backdrop-blur-md shadow-lg shadow-white/5">
      <div className="text-2xl font-black text-purple-600 tracking-tighter">StockVista</div>
      <div className="hidden md:flex gap-8 text-sm text-gray-300 font-medium">
        <a href="#" className="hover:text-white transition-colors">Home</a>
        <a href="#" className="hover:text-white transition-colors">Features</a>
        <a href="#" className="hover:text-white transition-colors">Analyze</a>
        <a href="#" className="hover:text-white transition-colors">Compare</a>
        <a href="#" className="hover:text-white transition-colors">About</a>
      </div>
      <div className="hidden md:flex gap-4">
        <button className="px-5 py-2.5 text-sm font-medium rounded-full border border-gray-600 text-white hover:bg-gray-800 transition-colors">Login</button>
        <button className="px-5 py-2.5 text-sm font-medium rounded-full bg-purple-600 text-white hover:bg-purple-700 transition-colors shadow-[0_0_15px_rgba(147,51,234,0.5)]">Get Started</button>
      </div>
    </nav>
  </div>
);

const Hero = () => (
  <section className="text-center pt-32 pb-20 px-4 relative">
    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-purple-600/20 blur-[120px] rounded-full pointer-events-none"></div>
    
    <div className="relative z-10">
      <h1 className="text-5xl md:text-7xl font-bold mb-6 tracking-tight leading-tight">
        AI-POWERED STOCK ANALYTICS
      </h1>
      <p className="text-gray-400 max-w-2xl mx-auto text-lg md:text-xl mb-10">
        Analyze Indian stocks with AI-powered technical analysis, market indicators, and data-driven decision support — all in one platform.
      </p>
      <div className="flex flex-col sm:flex-row justify-center gap-4">
        <button className="px-8 py-3.5 text-sm font-semibold rounded-full bg-purple-600 text-white hover:bg-purple-700 transition-colors shadow-[0_0_20px_rgba(147,51,234,0.4)]">
          Get Started
        </button>
      </div>
    </div>
  </section>
);

const TrustBar = () => (
  <section className="flex justify-center px-4 pb-32 relative z-10">
    <div className="flex flex-col md:flex-row items-center gap-10 px-10 py-6 rounded-2xl border border-gray-700 bg-gray-900/80 backdrop-blur-md">
      <div className="flex items-center gap-6">
        <div className="flex flex-col">
          <div className="text-2xl font-bold text-white flex items-baseline gap-2">
            15+ <span className="text-[11px] text-gray-400 uppercase tracking-wider font-semibold">years of data</span>
          </div>
        </div>
      </div>
      <div className="w-px h-16 bg-gray-700 hidden md:block"></div>
      <div className="flex flex-wrap justify-center gap-10 items-center opacity-80">
         <div className="flex flex-col">
           <div className="text-2xl font-bold text-white flex items-baseline gap-2">
             5000+ <span className="text-[11px] text-gray-400 uppercase tracking-wider font-semibold">Trading days</span>
           </div>
         </div>
         <div className="w-px h-16 bg-gray-700 hidden md:block"></div>
         <div className="flex flex-col">
           <div className="text-2xl font-bold text-white flex items-baseline gap-2">
             100+ <span className="text-[11px] text-gray-400 uppercase tracking-wider font-semibold">Stocks support</span>
           </div>
         </div>
      </div>
    </div>
  </section>
);

const Services = () => {
  const services = [
    { title: "AI Analytics", desc: "Machine learning for intelligent stock analysis.", active: false },
    { title: "Technical Indicators", desc: "Analyze trends with powerful technical signals.", active: true },
    { title: "Market Intelligence", desc: "Understand stocks within the broader Indian market.", active: false },
    { title: "Stock Comparison", desc: "Compare stocks and uncover market differences.", active: false },
    { title: "Decision Support", desc: "Data-driven insights for smarter decisions.", active: false },
    { title: "Interactive Insights", desc: "Explore market data through dynamic visualizations.", active: false },
  ];

  return (
    <section className="px-4 pb-32 max-w-6xl mx-auto">
      <div className="text-center mb-16">
        <h2 className="text-4xl md:text-5xl font-bold mb-6 tracking-tight">Intelligent Analysis. <span className="text-purple-600">Data-Driven Decisions.</span></h2>
        <p className="text-gray-400 max-w-2xl mx-auto text-lg">
          Harness AI, machine learning, and technical market data to understand stock trends and make informed decisions across the Indian stock market.
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map((service, i) => (
          <div key={i} className={`p-8 rounded-3xl border transition-all duration-300 relative group cursor-pointer ${service.active ? 'bg-purple-600 border-purple-500 shadow-xl shadow-purple-900/20' : 'bg-[#0a0a0a] border-gray-800 hover:border-gray-700 hover:bg-[#111]'}`}>
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-8 ${service.active ? 'bg-white/20' : 'bg-gray-900 border border-gray-800'}`}>
               <Code2 className={`w-7 h-7 ${service.active ? 'text-white' : 'text-purple-600'}`} />
            </div>
            <h3 className={`text-xl font-bold mb-3 ${service.active ? 'text-white' : 'text-gray-100'}`}>{service.title}</h3>
            <p className={`text-sm leading-relaxed ${service.active ? 'text-purple-100' : 'text-gray-400'}`}>{service.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

const Stats = () => {
  const stats = [
    { 
      num: "✗", 
      title: "Traditional Market Analysis",
      points: [
        { title: "Limited Data Perspective", desc: "Manually analyzing multiple indicators and large volumes of historical data can be time-consuming." },
        { title: "Human Bias", desc: "Emotions and cognitive biases can influence how investors interpret market movements and make decisions." },
        { title: "Time-Consuming Analysis", desc: "Collecting data, calculating indicators, comparing trends, and evaluating patterns manually requires significant effort." }
      ]
    },
    { 
      num: "✓", 
      title: "AI-Powered Market Analysis",
      points: [
        { title: "Intelligent Data Processing", desc: "Analyze historical stock prices, volume, technical indicators, and market-level features through a unified pipeline." },
        { title: "Data-Driven Analysis", desc: "Machine learning models identify patterns in historical market data to support more informed stock analysis." },
        { title: "Technical Intelligence", desc: "Combine indicators such as RSI, MACD, moving averages, Bollinger Bands, ATR, ADX, and volatility for deeper market understanding." }
      ]
    },
  ];

  return (
    <section className="bg-[#240a59] py-32 px-4 text-center">
       <div className="max-w-6xl mx-auto">
         <h2 className="text-4xl md:text-5xl font-bold mb-6 tracking-tight text-white">Human Intuition vs. AI Precision</h2>
         <p className="text-purple-200/80 max-w-2xl mx-auto mb-20 text-lg">
           Why automated intelligence outperforms traditional manual analysis.
         </p>
         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           {stats.map((stat, i) => (
             <div key={i} className="p-8 rounded-3xl border border-purple-400/30 bg-purple-900/20 text-left relative group hover:bg-purple-800/40 transition-colors cursor-pointer backdrop-blur-sm h-full flex flex-col">
               <div className="text-5xl md:text-6xl font-light text-white mb-8">{stat.num}</div>
               <h3 className="text-3xl font-bold pr-8 text-white mb-8">{stat.title}</h3>
               {stat.points && stat.points.length > 0 && (
                 <div className="space-y-6 mt-auto">
                   {stat.points.map((point, idx) => (
                     <div key={idx}>
                       <h4 className="text-purple-300 font-semibold mb-1">{point.title}</h4>
                       <p className="text-gray-300 text-sm leading-relaxed">{point.desc}</p>
                     </div>
                   ))}
                 </div>
               )}
             </div>
           ))}
         </div>
       </div>
    </section>
  );
};

const Portfolio = () => {
  const projects = [
    { category: "All-in-One", title: "Complete Market View", desc: "Bring stock data, technical indicators, market trends, and AI analysis together in one platform." },
    { category: "Explainable", title: "Understand the Analysis", desc: "Go beyond the result and explore the market factors and indicators behind the AI-driven analysis." },
    { category: "ML-Driven", title: "Data-Driven Intelligence", desc: "Machine learning models analyze historical market patterns to support more informed decisions." },
  ];

  return (
    <section className="py-32 px-4 max-w-6xl mx-auto">
      <div className="text-center mb-20">
        <h2 className="text-4xl md:text-5xl font-bold tracking-tight">Why This Platform</h2>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
        {projects.map((proj, i) => (
          <div key={i} className="p-8 rounded-3xl border border-gray-800 bg-[#0a0a0a] hover:border-gray-700 transition-colors cursor-pointer group">
             <div className="text-purple-600 text-xs font-bold uppercase tracking-wider mb-6">{proj.category}</div>
             <h3 className="text-2xl font-bold mb-4 text-white group-hover:text-purple-400 transition-colors">{proj.title}</h3>
             <p className="text-gray-400 text-sm leading-relaxed">{proj.desc}</p>
          </div>
        ))}
      </div>
      <div className="text-center">
        <button className="px-8 py-3.5 text-sm font-semibold rounded-full bg-purple-600 text-white hover:bg-purple-700 transition-colors shadow-[0_0_20px_rgba(147,51,234,0.3)]">
          View All Services
        </button>
      </div>
    </section>
  );
};

const Testimonials = () => {
  return (
    <section className="pt-24 pb-24 px-4 max-w-6xl mx-auto text-center overflow-hidden">
      <h2 className="text-3xl md:text-4xl font-bold">Empowering every investor with <span className="text-purple-500">intelligent Market Analytics</span></h2>
    </section>
  );
};

export default function App() {
  return (
    <div className="min-h-screen bg-black text-white font-sans selection:bg-purple-600/30 overflow-x-hidden">
      <Navbar />
      <main>
         <Hero />
         <TrustBar />
         <Services />
         <Stats />
         <Portfolio />
         <Testimonials />
      </main>
    </div>
  );
}
